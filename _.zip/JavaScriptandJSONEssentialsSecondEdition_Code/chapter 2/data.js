let data_json = [
	{
		"emp_no" 		: "10001",
		"birth_date" 	: "1980-09-02",
		"first_name" 	: "Georgi",
		"last_name"  	: "Facello",
		"gender" 	 	: "M",
		"hire_date" 	: "2010-09-04",
		"designation" 	: {
			"title" 	: "Junior Engineer",
			"From_date" : "2010-09-04",
			"to_date" 	: "2017-10-11"
		}
	},
	{
		"emp_no" 		: "10002",
		"birth_date" 	: "1970-09-02",
		"first_name" 	: "Will",
		"last_name"  	: "Scott",
		"gender" 	 	: "M",
		"hire_date" 	: "2005-09-04",
		"designation" 	: {
			"title" 	: ["Senior Engineer", "Author", "Trainer"],
			"From_date" : "2005-09-04",
			"to_date" 	: "2017-10-11"
		}
	},
	{
		"emp_no" 		: "10003",
		"birth_date" 	: "1960-09-02",
		"first_name" 	: "Jenny",
		"last_name"  	: "Souza",
		"gender" 	 	: "F",
		"hire_date" 	: "2006-10-05",
		"designation" 	: {
			"title" 	: "Architect",
			"From_date" : "2006-10-05",
			"to_date" 	: "2017-10-11"
		}
	}
	// And so on
]
