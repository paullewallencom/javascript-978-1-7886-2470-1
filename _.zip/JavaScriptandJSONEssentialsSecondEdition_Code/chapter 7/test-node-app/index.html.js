//index.html.js
module.exports = `
<!DOCTYPE html>
<html>
<head>
	<title>Hello readers</title>
</head>
<body>
	<h2>Greeting {{audience}}!</h2>
	<h3>Life is {{adjective}}</h3>
</body>
</html>
`