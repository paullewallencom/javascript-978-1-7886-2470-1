module.exports = {
	"port" : 3300,
	"audience" : "readers"
}