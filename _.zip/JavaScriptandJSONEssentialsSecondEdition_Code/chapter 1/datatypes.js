let nullVal = "";
alert(typeof nullVal); //prints string
nullVal = null;
alert(typeof nullVal); //prints object